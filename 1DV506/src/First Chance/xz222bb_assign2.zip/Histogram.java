package xz222bb_assign2;

public class Histogram {
    public static void main(String[] args) {
        final int NUMBER_OF_DICES = 500;
    }

    public static void Dice(int playerDice) {
        for (int NUMBER_OF_DICES = 1; NUMBER_OF_DICES <= 500; NUMBER_OF_DICES++) {
            int n1 = (int) (Math.random() * 6 + 1);
        }
    }
}
