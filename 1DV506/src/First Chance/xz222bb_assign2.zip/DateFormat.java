package xz222bb_assign2;

import java.util.Scanner;

public class DateFormat {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        input.close();

        System.out.print("Enter a year: ");
        int year = input.nextInt();
        System.out.print("Enter a month (number): ");
        int month = input.nextInt();
        System.out.print("Enter a day (number): ");
        int day = input.nextInt();
        System.out.print("Enter a format (b/l/m): ");
        String endian = "b/l/m";
        endian = input.nextLine();

        if (endian.equals("b")) {
            endian = input.nextLine();
            big_endian(year, month, day);
        }
        else if (endian.equals("l")) {
            endian = input.nextLine();
            little_endian(year, month, day);
        }
        else if (endian.equals("m")) {
            endian = input.nextLine();
            middle_endian(year, month, day);
        }
    }

    public static void big_endian (int year, int month, int day) {
        String endian = "b";
        System.out.println(year + "/" + month + "/" + day);
    }

    public static void little_endian (int year, int month, int day){
        String endian = "l";
        System.out.println(day + "/" + month + "/" + year);
    }

    public static void middle_endian (int year, int month, int day){
        String endian = "m";
        System.out.println(month + "/" + day + "/" + year);
    }
}
