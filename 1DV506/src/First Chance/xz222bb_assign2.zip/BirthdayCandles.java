package xz222bb_assign2;

import javax.swing.*;

public class BirthdayCandles {
    public static void main(String[] args) {
        double NUMBER_OF_CANDLES_PER_BOX = 24;
        double NumberOfBoxes = 0;
        double NumberOfSavedCandles = 0;
        double TotalBoxes = 0;
        double age = 1;

        while (age <= 100) {
            if (NumberOfSavedCandles < age) {
                NumberOfBoxes = (int) (Math.ceil(age / NUMBER_OF_CANDLES_PER_BOX * 10 / 10));
                NumberOfSavedCandles = (NumberOfSavedCandles + NumberOfBoxes * NUMBER_OF_CANDLES_PER_BOX) - age;
                System.out.println("Before birthday " + (int) age + ", buy " + (int) NumberOfBoxes + " box(es)");
                TotalBoxes += NumberOfBoxes;
            }
            else {
                NumberOfSavedCandles -= age;
            }

            age++;
        }

        System.out.println("Total number of boxes: " + (int) TotalBoxes +
                ", Remaining candle: " + (int) NumberOfSavedCandles);
    }
}
