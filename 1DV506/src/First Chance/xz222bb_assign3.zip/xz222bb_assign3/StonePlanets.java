package xz222bb_assign3;

import javax.swing.*;
import java.lang.reflect.Array;

public class StonePlanets {
    public static void main(String[] args) {
        Planet[] no = new Planet[4];
        no[0] = new Planet("Mercury", 0, 0, 0.47, 0.31);
        no[1] = new Planet("Venus", 0, 0, 0.72, 0.72);
        no[2] = new Planet("Earth", 0, 1, 1.0, 0.99);
        no[3]= new Planet("Mars", 4, 2, 1.666, 1.382);

        Moon moon = new Moon("The Moon", 0);
        Moon phobos = new Moon("Phobos", 0);
        Moon deimos = new Moon("Deimos", 0);

        System.out.println("Planet " + no[0].getName() +" has aphelion " + no[0].getAphelion() + " AU, perihelion " + no[0].getPerihelion() + " AU and " + no[0].getNoOfMoons()+" moons.");
        System.out.println("Planet " + no[1].getName() +" has aphelion " + no[1].getAphelion() + " AU, perihelion " + no[1].getPerihelion() + " AU and " + no[1].getNoOfMoons()+" moons.");
        System.out.println("Planet " + no[2].getName() +" has aphelion " + no[2].getAphelion() + " AU, perihelion " + no[2].getPerihelion() + " AU and " + no[2].getNoOfMoons()+" moons.");
        no[2].addMoon(moon);
        System.out.println("Planet " + no[3].getName() +" has aphelion " + no[3].getAphelion() + " AU, perihelion " + no[3].getPerihelion() + " AU and " + no[3].getNoOfMoons()+" moons.");
        no[3].addMoon(phobos);
        no[3].addMoon(deimos);
    }
}
