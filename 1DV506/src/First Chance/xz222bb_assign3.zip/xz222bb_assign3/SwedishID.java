package xz222bb_assign3;

import javax.swing.*;
import java.util.Date;

public class SwedishID {
    DateFormat birthday = new DateFormat();
    int serialNumber;
    int checksum;
    boolean valid;

    public SwedishID(String id) {
        this.birthday.setYear(Integer.parseInt(id.substring(0, 4)));
        this.birthday.setMonth(Integer.parseInt(id.substring(4, 6)));
        this.birthday.setDay(Integer.parseInt(id.substring(6, 8)));
        this.birthday.setPunctuation("!");
        this.birthday.setFormat("b");
        this.serialNumber = Integer.parseInt((id.substring(9,12)));
        this.checksum = Integer.parseInt(id.substring(12));
    }

    public DateFormat getBirthday() {
        return birthday;
    }

    public void setBirthday(DateFormat birthday) {
        this.birthday = birthday;
    }

    public int getChecksum() {
        return checksum;
    }

    public void setChecksum(int checksum) {
        this.checksum = checksum;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public String showID() {
        return this.birthday.getDate(true) + "-" + this.serialNumber + this.checksum;
    }

    public boolean isFemale() {
        return this.checksum % 2 == 0;
    }

    public int comparedTo(SwedishID otherID) {
        return this.birthday.getDate(false).compareTo(otherID.birthday.getDate(false));
    }

    public boolean validID() {
        int check = 0;
        int dig2 = birthday.toString().charAt(2) * 2;
        int dig3 = birthday.toString().charAt(3);
        int dig4 = birthday.toString().charAt(4) * 2;
        int dig5 = birthday.toString().charAt(5);
        int dig6 = birthday.toString().charAt(6) * 2;
        int dig7 = birthday.toString().charAt(7);
        int dig9 = birthday.toString().charAt(9) * 2;
        int dig10 = birthday.toString().charAt(10);
        int dig11 = birthday.toString().charAt(11) * 2;

        int sum = dig2 + dig3 + dig4 + dig5 + dig6 + dig7 + dig9 + dig10 + dig11;

        int lastDigOfSum = sum % 10;
        check = 10 - lastDigOfSum;

        return this.checksum == check;
    }
}
