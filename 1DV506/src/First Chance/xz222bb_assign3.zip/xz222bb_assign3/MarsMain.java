package xz222bb_assign3;

public class MarsMain {
    public static void main(String[] args) {
        Planet mars = new Planet("Mars", 4, 2, 1.666, 1.382);
        mars.print();
    }
}
