package xz222bb_assign4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CountingWords {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("C:\\Users\\Yun\\IdeaProjects\\1DV506 Assignments\\src\\xz222bb_assign4\\lovecraft.txt");
        Scanner input = new Scanner(file);

        int words = 0;

        while (input.hasNext()) {
            String s1 = input.nextLine();
            words += count(s1);
        }
        System.out.println("Number of words: " + words);
    }

    public static int count(String str) {
        if (str == null || str.isEmpty()) {
            return 0;
        }

        int wordCount = 0;

        boolean isWord = false;
        int endOfLine = str.length() - 1;
        char[] characters = str.toCharArray();

        for (int i = 0; i < characters.length; i++) {
            if (Character.isLetter(characters[i]) && i != endOfLine) {
                isWord = true;
            }
            else if (!Character.isLetter(characters[i]) && isWord) {
                wordCount++;
                isWord = false;
            }
            else if (Character.isLetter(characters[i]) && i == endOfLine) {
                wordCount++;
            }
        }
        return wordCount;
    }
}
