package xz222bb_assign4;

import java.io.File;
import java.util.Scanner;

public class Statistics {
    public static void main(String[] args) throws Exception {
        File file = new File("C:\\Users\\Yun\\IdeaProjects\\1DV506 Assignments\\src\\xz222bb_assign4\\lovecraft.txt");

        Scanner input = new Scanner(file);

        int linesTotal = 0; //Total lines
        int emptyLines = 0; //Empty lines
        int textLines = 0;
        int pageNumber = 0;
        // lines with text = !page number & ! empty line

        while (input.hasNext()) {
            String s1 = input.nextLine();
            linesTotal++;
            if (s1.isEmpty()) {
                emptyLines++;
            }
            else if (!(s1.isEmpty()) && checkNumber(s1))
                textLines++;
            else if (!checkNumber(s1))
                pageNumber++;

        }
        System.out.println("Total lines: " + linesTotal);
        System.out.println("Empty lines: " + emptyLines);
        System.out.println("Lines with text: " + textLines);
        System.out.println("Lines with page number: " + pageNumber);

        input.close();
    }

    private static boolean checkNumber(String str) {
        for (int n = 0; n <= str.length() - 1; n++) {
            if (str.charAt(n) >= 48 && str.charAt(n) <= 57) {
                return false;
            }
        }
        return true;
    }
}
