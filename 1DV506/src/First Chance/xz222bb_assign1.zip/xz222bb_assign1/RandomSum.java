package xz222bb_assign1;

import java.util.Scanner;

public class RandomSum {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Five random numbers: ");
        double number1 = input.nextDouble();
        double number2 = input.nextDouble();
        double number3 = input.nextDouble();
        double number4 = input.nextDouble();
        double number5 = input.nextDouble();
        double sum = number1 + number2 + number3 + number4 + number5;
        System.out.println("There sum is " + sum);

    }
}
