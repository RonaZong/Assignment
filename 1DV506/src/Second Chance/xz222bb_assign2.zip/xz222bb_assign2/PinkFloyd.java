package xz222bb_assign2;

public class PinkFloyd {
    public static void main(String[] args) {
        int i;
        for (i = 0; i < 5; i++) {
            System.out.println("Pink Floyd rules!");
        }
    }
}
