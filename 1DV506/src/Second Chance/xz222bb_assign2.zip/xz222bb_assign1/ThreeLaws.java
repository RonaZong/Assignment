package xz222bb_assign1;

public class ThreeLaws {
    public static void main(String[] args) {
        System.out.println("1. A robot may not injure a human being or, through inaction, allow a human being to come to harm.\n" +
                "2. A robot must obey the orders given it by human beings except where such orders would conflict with the First Law.\n" +
                "3. A robot must protect its own existence as long as such protection does not conflict with the First or Second Laws.");
    }
}
