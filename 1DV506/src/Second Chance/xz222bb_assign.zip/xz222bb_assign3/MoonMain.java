package xz222bb_assign3;

public class MoonMain {
    public static void main(String[] args) {
        Moon ganymede = new Moon("Ganymede", 5262);
        ganymede.print();
    }
}
